
var localizedStrings = new Object;

